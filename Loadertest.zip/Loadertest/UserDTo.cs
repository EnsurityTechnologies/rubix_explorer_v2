﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loadertest
{
    public class UserDTo
    {
        public string UserDID { get; set; }

        public string Balance { get; set; }

        public string CreationTime { get; set; }
    }
}
